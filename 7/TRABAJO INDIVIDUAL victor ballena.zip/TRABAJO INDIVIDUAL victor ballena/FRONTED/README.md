# Carrito de compras usando React Context y Sass muy FACIL!
Video en youtube: https://www.youtube.com/watch?v=ywvsztMU_oM&ab_channel=Mauro

![image](https://user-images.githubusercontent.com/81174890/154757409-06fe6a41-c264-4ff7-a23e-f88bcb86354f.png)
![image](https://user-images.githubusercontent.com/81174890/154757437-dc2f3870-ab4a-4a9f-ba5e-043fcf4d1241.png)
![image](https://user-images.githubusercontent.com/81174890/154757473-aec0bf06-05d9-45fa-87c8-68d3f56f6f64.png)
