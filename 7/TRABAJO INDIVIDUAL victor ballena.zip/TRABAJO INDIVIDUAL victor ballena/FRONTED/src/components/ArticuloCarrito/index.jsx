import React, { useContext } from "react";
import carritocontexto from "../../contexto/carritocontexto";
import styles from "./estilos.module.scss";

export const ArticuloCarrito = ({ producto }) => {
  const { editarproductocarro } = useContext(carritocontexto);

  return (
    <div className={styles.productoCarrito}>
      <img src={producto.img} alt={producto.nombre} />
      <div className={styles.contenedorDatos}>
        <div className={styles.izquierda}>
          <p>{producto.nombre}</p>
          <div className={styles.botones}>
            <button onClick={() => editarproductocarro(producto._id, "add", producto.cantidad)}>
              AGREGAR
            </button>
            <button onClick={() => editarproductocarro(producto._id, "del", producto.cantidad)}>
              ELIMINAR
            </button>
          </div>
        </div>
        <div className={styles.derecha}>
          <div>{producto.cantidad}</div>
          <p>Total: ${producto.cantidad * producto.precio}</p>
        </div>
      </div>
    </div>
  );
};