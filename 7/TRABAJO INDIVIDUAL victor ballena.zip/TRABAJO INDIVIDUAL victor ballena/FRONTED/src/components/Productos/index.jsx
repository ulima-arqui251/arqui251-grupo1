import React, { useContext } from "react";
import CarritoContexto from "../../contexto/carritocontexto";
import styles from "./estilos.module.scss";

const Productos = () => {
  // Traemos del contexto la función para agregar un producto y la lista de productos
  const { adicionarproductocarro, productos } = useContext(CarritoContexto);

  return (
    <div className={styles.contenedorProductos}>
      {productos &&
        productos.map((producto, i) => (
          <div key={i} className={styles.producto}>
            <img src={producto.img} alt={producto.nombre} />
            <div>
              <p>
                {producto.nombre} - ${producto.precio}
              </p>
            </div>
            {!producto.inCart ? (
              <button onClick={() => adicionarproductocarro(producto)}>
                Añadir al carrito
              </button>
            ) : (
              <button>En el carrito</button>
            )}
          </div>
        ))}
    </div>
  );
};

export default Productos;
