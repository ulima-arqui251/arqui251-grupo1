import { useContext, useEffect, useState } from "react";
import { ArticuloCarrito } from "../ArticuloCarrito";
import CarritoContexto from "../../contexto/carritocontexto";
import styles from "./estilos.module.scss";

const Carrito = () => {
  // Creamos 2 estados: uno para saber si el carrito está abierto,
  // y otro para contar la cantidad total de productos
  const [abrirCarrito, setAbrirCarrito] = useState(false);
  const [cantidadProductos, setCantidadProductos] = useState(0);

  // Obtenemos los productos del carrito desde el contexto
  const { productocarro: productosCarrito } = useContext(CarritoContexto);


  // Cada vez que se modifica el carrito, actualizamos la cantidad de productos
  useEffect(() => {
    setCantidadProductos(
      productosCarrito?.reduce(
        (acumulado, actual) => acumulado + actual.cantidad,
        0
      )
    );
  }, [productosCarrito]);

  // Calculamos el precio total
  const total = productosCarrito?.reduce(
    (acumulado, actual) => acumulado + actual.cantidad * actual.precio,
    0
  );

  return (
    <div className={styles.contenedorCarrito}>
      <div
        onClick={() => setAbrirCarrito(!abrirCarrito)}
        className={styles.contenedorBotonCarrito}
      >
        <div className={styles.botonCarrito}>
          {!abrirCarrito ? (
            // Ícono de abrir carrito
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="30"
              height="30"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#F0F0F0"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
  <circle cx="9" cy="21" r="1" />
  <circle cx="20" cy="21" r="1" />
  <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
</svg>

          ) : (
            // Ícono de cerrar carrito
            <svg
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="..." fill="#F0F0F0" />
            </svg>
          )}
        </div>

        {!abrirCarrito && (
          <div className={styles.numeroProductos}>{cantidadProductos}</div>
        )}
      </div>

      {productosCarrito && abrirCarrito && (
        <div className={styles.carrito}>
          <h2>Tu carrito</h2>

          {productosCarrito.length === 0 ? (
            <p className={styles.carritoVacio}>Tu carrito está vacío</p>
          ) : (
            <div className={styles.contenedorProductos}>
              {productosCarrito.map((item, i) => (
                <ArticuloCarrito key={i} producto={item} />
              ))}
            </div>
          )}

          <h2 className={styles.total}>Total: ${total}</h2>
        </div>
      )}
    </div>
  );
};

export default Carrito;
