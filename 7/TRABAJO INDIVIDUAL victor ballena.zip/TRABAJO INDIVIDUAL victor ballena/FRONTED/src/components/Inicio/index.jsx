import React from "react";
import Carro from "../Carro";
import Productos from "../Productos";
import styles from './estilos.module.scss';

const Inicio = () => {
  return (
    <div className={styles.inicio}>
      <Carro />
      <Productos />
    </div>
  );
};

export default Inicio;