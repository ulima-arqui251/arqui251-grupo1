import { createContext, useEffect, useState } from "react";
import axios from "axios";

// Crear el contexto
const carritocontexto = createContext();

export const Carritoproveedor = ({ children }) => {
  const [productocarro, setProductocarro] = useState([]);
  const [productos, setProductos] = useState([]);

  // Obtener todos los productos
  const getProductos = async () => {
    try {
      const { data } = await axios.get("http://localhost:4000/productos");
      setProductos(data.productos);
    } catch (error) {
      console.error("Error al obtener productos", error);
    }
  };

  // Obtener productos del carrito
  const getProductocarro = async () => {
    try {
      const { data } = await axios.get("http://localhost:4000/productos-carro");
      setProductocarro(data.productocarro);
    } catch (error) {
      console.error("Error al obtener productos del carrito", error);
    }
  };

  useEffect(() => {
    getProductos();
    getProductocarro();
  }, []);

  // Agregar un producto al carrito
  const adicionarproductocarro = async (producto) => {
    const { nombre, img, precio } = producto;

    try {
      await axios.post("http://localhost:4000/productos-carro", {
        nombre,
        img,
        precio,
      });
      await getProductos();
      await getProductocarro();
    } catch (error) {
      console.error("Error al agregar producto al carrito", error);
    }
  };

  // Editar cantidad del producto en el carrito (agregar o eliminar)
  const editarproductocarro = async (id, query, cantidad) => {
    try {
      if (query === "del" && cantidad === 1) {
        await axios.delete(`http://localhost:4000/productos-carro/${id}`);
      } else {
        await axios.put(`http://localhost:4000/productos-carro/${id}?query=${query}`, {
          cantidad,
        });
      }

      await getProductos();
      await getProductocarro();
    } catch (error) {
      console.error("Error al editar producto del carrito", error);
    }
  };

  return (
    <carritocontexto.Provider
      value={{
        productocarro,
        productos,
        adicionarproductocarro,
        editarproductocarro,
      }}
    >
      {children}
    </carritocontexto.Provider>
  );
};

export default carritocontexto;
