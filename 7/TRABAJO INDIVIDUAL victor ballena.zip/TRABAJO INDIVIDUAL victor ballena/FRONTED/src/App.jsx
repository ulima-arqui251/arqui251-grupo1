import "./App.scss";
import React from "react";
import Inicio from "./components/Inicio";
import { Carritoproveedor } from "./contexto/carritocontexto";

const App = () => {
  // Envolvemos la página de inicio con el proveedor del contexto del carrito
  return (
    <Carritoproveedor>
      <Inicio />
    </Carritoproveedor>
  );
};

export default App;
