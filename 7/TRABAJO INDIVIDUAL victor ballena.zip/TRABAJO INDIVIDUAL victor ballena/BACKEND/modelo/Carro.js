const { model, Schema } = require("mongoose");

const CarroSchema = new Schema({
  nombre: { type: String, required: true, unique: true },
  img: { type: String, required: true },
  cantidad: { type: Number, required: true },
  precio: { type: Number, required: true },
});

module.exports = model("Carro", CarroSchema);
