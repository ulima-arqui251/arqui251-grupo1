const { model, Schema } = require("mongoose");

const ProductoSchema = new Schema({
  nombre: { type: String, required: true, unique: true },
  img: { type: String, required: true },
  enCarrito: { type: Boolean, default: false },
  precio: { type: Number, required: true },
});

module.exports = model("Producto", ProductoSchema);
