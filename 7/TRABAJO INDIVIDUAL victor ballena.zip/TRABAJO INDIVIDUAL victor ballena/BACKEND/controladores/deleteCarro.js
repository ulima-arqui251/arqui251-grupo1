const ProductoCarro = require("../modelo/Carro");
const Producto = require("../modelo/Producto");

const deleteCarro = async (req, res) => {
  const { productId } = req.params;

  // Buscamos el producto en el carrito
  const productoEnCarro = await ProductoCarro.findById(productId);

  // Buscamos el producto en nuestra base de datos por su nombre
  const { nombre, img, precio, _id } = await Producto.findOne({
    nombre: productoEnCarro.nombre,
  });

  // Eliminamos el producto del carrito
  await ProductoCarro.findByIdAndDelete(productId);

  // Actualizamos la propiedad inCart a false en la base de datos de productos
  await Producto.findByIdAndUpdate(
    _id,
    { inCart: false, nombre, img, precio },
    { new: true }
  )
    .then((producto) => {
      res.json({
        mensaje: `El producto ${producto.nombre} fue eliminado del carrito`,
      });
    })
    .catch((error) =>
      res.status(500).json({ mensaje: "Hubo un error al eliminar el producto" })
    );
};

module.exports = deleteCarro;
