const Producto = require("../modelo/Producto");

const getProductos = async (req, res) => {
  const productos = await Producto.find();

  if (productos && productos.length > 0) {
    res.json({ productos });
  } else {
    res.json({ mensaje: "No hay productos" });
  }
};

module.exports = getProductos;