const ProductoCarro = require("../modelo/Carro");
const Producto = require("../modelo/Producto");

const postCarro = async (req, res) => {
  const { nombre, img, precio } = req.body;

  // Verificamos si el producto existe en la base de datos
  const existeEnProductos = await Producto.findOne({ nombre });

  // Verificamos que todos los campos tengan información
  const camposCompletos = nombre !== "" && img !== "" && precio !== "";

  // Verificamos si el producto ya está en el carrito
  const yaEnCarrito = await ProductoCarro.findOne({ nombre });

  // Si el producto no está en la base de datos
  if (!existeEnProductos) {
    res.status(400).json({
      mensaje: "Este producto no se encuentra en nuestra base de datos",
    });

  // Si los campos están completos y el producto no está en el carrito
  } else if (camposCompletos && !yaEnCarrito) {
    const nuevoProductoCarro = new ProductoCarro({ nombre, img, precio, cantidad: 1 });

    // Actualizamos la propiedad inCart a true en la colección de productos
    await Producto.findByIdAndUpdate(
      existeEnProductos?._id,
      { inCart: true, nombre, img, precio },
      { new: true }
    )
      .then((producto) => {
        nuevoProductoCarro.save();
        res.json({
          mensaje: `El producto fue agregado al carrito`,
          producto,
        });
      })
      .catch((error) => console.error(error));

  // Si ya está en el carrito
  } else if (yaEnCarrito) {
    res.status(400).json({
      mensaje: "El producto ya está en el carrito",
    });
  }
};

module.exports = postCarro;
