const Carro = require("../modelo/Carro");
const getCarro = async (req, res) => {
  const productocarro = await Carro.find();

  if (productocarro && productocarro.length > 0) {
    res.json({ productocarro });
  } else {
    res.json({ mensaje: "No hay productos en el carrito" });
  }
};

module.exports = getCarro;
