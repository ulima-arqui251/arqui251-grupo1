const Carro = require("../modelo/Carro");

const putCarro = async (req, res) => {
  const { productId } = req.params;
  const { query } = req.query;

  try {
    const producto = await Carro.findById(productId);
    if (!producto) return res.status(404).json({ mensaje: "Producto no encontrado" });

    if (!producto.cantidad) producto.cantidad = 1;

    if (query === "add") {
      producto.cantidad += 1;
    } else if (query === "del") {
      producto.cantidad -= 1;
    }

    if (producto.cantidad <= 0) {
      await Carro.findByIdAndDelete(productId);
      return res.json({ mensaje: "Producto eliminado del carrito" });
    }

    const actualizado = await producto.save();
    res.json({ mensaje: "Actualizado correctamente", producto: actualizado });
  } catch (error) {
    console.error("Error en putCarro", error);
    res.status(500).json({ mensaje: "Error del servidor" });
  }
};

// ✅ IMPORTANTE: exporta correctamente como función, no como objeto
module.exports = putCarro;
