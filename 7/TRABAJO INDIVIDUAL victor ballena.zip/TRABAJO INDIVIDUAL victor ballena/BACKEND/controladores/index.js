const getProductos = require("./getProductos");
const getCarro = require("./getProductosCarro");
const addProductoCarro = require("./addProductoCarro");
const putCarro = require("./putCarro"); // ✅ nombre correcto
const deleteCarro = require("./deleteCarro");

module.exports = {
  getProductos,
  getCarro,
  addProductoCarro,
  putCarro,
  deleteCarro,
};
