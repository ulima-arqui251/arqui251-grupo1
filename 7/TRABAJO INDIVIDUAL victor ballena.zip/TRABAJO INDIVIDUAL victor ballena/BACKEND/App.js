const express = require("express");
const cors = require("cors");

const db = require("./database");
const controladores = require("./controladores");

const app = express();

app.use(cors());
app.use(express.json());

// RUTAS

// GET: Obtener productos y carrito
app.get("/productos", controladores.getProductos);
app.get("/productos-carro", controladores.getCarro);

// POST: Agregar producto al carrito
app.post("/productos-carro", controladores.addProductoCarro);

// PUT: Actualizar cantidad de producto en el carrito
// ⚠️ Corregido para que coincida con `productId` usado en el controlador
app.put("/productos-carro/:productId", controladores.putCarro);

// DELETE: Eliminar producto del carrito
app.delete("/productos-carro/:productId", controladores.deleteCarro);

// INICIAR SERVIDOR
app.listen(4000, () => {
  console.log("Servidor funcionando en el puerto 4000");
  db();
});

module.exports = app;
