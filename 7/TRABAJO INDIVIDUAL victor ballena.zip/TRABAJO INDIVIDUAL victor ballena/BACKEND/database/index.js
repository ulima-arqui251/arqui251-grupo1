const mongoose = require("mongoose");

const URL_MONGO = "mongodb://localhost/carrito";

const conexionBD = async () => {
  await mongoose
    .connect(URL_MONGO)
    .then(() => console.log("Base de datos conectada correctamente"))
    .catch((error) => console.error("Error al conectar la base de datos:", error));
};

module.exports = conexionBD;
